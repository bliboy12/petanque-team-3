create definer = root@localhost view vseizoensklassement as
select `s`.`seizoensId`           AS `seizoensId`,
       `d`.`spelerId`             AS `spelerId`,
       `s2`.`naam`                AS `spelerNaam`,
       `s2`.`voornaam`            AS `spelerVoornaam`,
       sum(`d`.`hoofdpunten`)     AS `hoofdpunten`,
       sum(`d`.`plus_min_punten`) AS `plus_min_punten`
from ((`petanque`.`dagklassement` `d` join `petanque`.`speeldag` `s`
       on ((`d`.`speeldagId` = `s`.`speeldagId`))) join `petanque`.`speler` `s2`
      on ((`d`.`spelerId` = `s2`.`spelerId`)))
group by `s`.`seizoensId`, `d`.`spelerId`;

